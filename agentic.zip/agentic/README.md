# Cloudflare AI Receptionist Demo

This repository contains a minimal full‑stack application that follows the
architecture outlined in the **Cloudflare AI Receptionist** design document.
The goal of this project is to provide a starting point for building an
autonomous receptionist that can handle inbound calls, perform natural
language understanding and synthesis, and expose a simple web interface. It is
implemented using a React single‑page application (SPA) powered by Vite on
the frontend and a Cloudflare Worker (via the Hono framework) on the
backend.

> **Important**: The code in this repository is a demonstration. The API
> endpoints return mock data and do not perform real calls, LLM inference or
> text‑to‑speech synthesis. It is intended to show how the pieces fit
> together and to act as a scaffold for your own integration with
> Cloudflare Calls, D1, R2, KV, Vectorize and Workers AI.

## Features

- **React/Vite frontend** – A simple chat UI that lets you send messages to
  the backend and initiate a fake call. Messages are displayed in a chat
  window with basic styling.
- **Cloudflare Worker backend** – Implements REST endpoints for call
  sessions, SIP bridging, retrieval‑augmented search, language model
  generation and text‑to‑speech. Responses are currently stubbed.
- **Local development script** – `npm run dev` concurrently launches
  Wrangler’s development server for the Worker and Vite’s dev server for the
  frontend. API requests from the frontend are proxied to the Worker.
- **Provisioning stub** – `npm run provision` outputs the commands you would
  run to create Cloudflare resources (D1, R2, KV, Vectorize, Calls). Fill
  this in with your own deployment steps.

## Getting Started

1. **Install dependencies**

   ```bash
   cd agentic
   npm install
   ```

2. **Start the development environment**

   ```bash
   npm run dev
   ```

   This will seed the (mock) database, start `wrangler dev` on port
   `8787` and run `vite` on port `5173`. The `vite.config.ts` proxies
   API calls to the Worker so you can interact with the backend from your
   browser.

3. **Open the app**

   Navigate to `http://localhost:5173` in your browser. You should see a
   chat interface. Try sending a message or clicking the **Start Call**
   button to see the stub responses.

4. **Provision Cloudflare resources (optional)**

   Run `npm run provision` to see which Wrangler commands you would need to
   execute to create the D1 database, R2 bucket, KV namespace, Vectorize
   index and Calls binding. This script does not actually create anything
   without Cloudflare credentials.

## Project Structure

```
agentic/
├── backend/              # Cloudflare Worker source
│   └── worker.ts         # API routes implemented with Hono
├── ops/                  # Operations scripts
│   ├── cloudflare.ts     # Stub to provision resources
│   └── devops.ts         # Starts Wrangler and Vite concurrently
├── src/                  # React frontend source
│   ├── App.tsx           # Main React component
│   ├── index.css         # Global styles
│   └── main.tsx          # React entry point
├── wrangler.toml         # Worker configuration
├── vite.config.ts        # Vite configuration with API proxy
├── package.json          # Node metadata and scripts
└── tsconfig.json         # TypeScript compiler settings
```

## Extending This Demo

To build a production‑ready AI receptionist you will need to implement
several pieces not included in this sample:

- **Cloudflare Calls integration** – Acquire a Calls token from your account
  and negotiate WebRTC sessions for inbound callers. You may also need to
  integrate Kamailio and rtpengine as described in the design document for
  SIP/PSTN interoperability.
- **LLM and RAG** – Replace the stubbed `/llm/generate` and `/rag/search`
  endpoints with real calls to an LLM provider and a vector search index.
- **Text‑to‑speech** – Use Workers AI’s TTS model or your preferred
  provider to synthesize audio for replies.
- **Data persistence** – Connect to a D1 database for storing tenants,
  users, agents, call logs and other entities. Persist usage counters and
  appointments.
- **Security** – Store API keys and secrets securely using Wrangler’s
  secret management. Configure CORS and authentication for your API.

With these additions the scaffold in this repository will evolve into a
fully‑featured, Cloudflare‑native voice agent. Contributions and
customisations are welcome!