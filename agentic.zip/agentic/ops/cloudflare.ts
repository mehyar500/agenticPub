#!/usr/bin/env node
/**
 * Provision Cloudflare resources required for the AI receptionist. In a real
 * environment this script would call the Wrangler CLI to create D1, R2,
 * Vectorize, KV and Calls resources. Because this code is intended to run
 * locally and without any credentials, the implementation here simply logs
 * which resources would be created. Feel free to customize this script to
 * suit your deployment process.
 */

import { spawnSync } from 'child_process';

function run(cmd: string, args: string[] = []): void {
  console.log(`Executing: ${cmd} ${args.join(' ')}`);
  const proc = spawnSync(cmd, args, { stdio: 'inherit' });
  if (proc.status !== 0) {
    throw new Error(`${cmd} failed with exit code ${proc.status}`);
  }
}

async function provision() {
  console.log('Provisioning Cloudflare resources...');
  console.log('Note: This script is a stub. Replace calls to `wrangler d1 create` etc.');

  // Example commands you might run when provisioning resources. These are
  // commented out because they require Cloudflare credentials and are not
  // executed in this environment.
  // run('wrangler', ['d1', 'create', 'agentic_db']);
  // run('wrangler', ['r2', 'create', 'agentic-bucket']);
  // run('wrangler', ['kv:namespace', 'create', '--binding', 'SESSIONS']);
  // run('wrangler', ['ai', 'vectorize:create', 'agentic-vectorize']);
  // run('wrangler', ['calls', 'create', 'agentic-calls']);

  console.log('Provisioning complete.');
}

provision().catch((err) => {
  console.error(err);
  process.exit(1);
});