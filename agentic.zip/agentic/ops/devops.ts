#!/usr/bin/env node
/**
 * DevOps entry point. This script starts both the Cloudflare Worker and the
 * React frontend concurrently. It also provides a convenient place to seed
 * the database with mock data or perform other setup tasks before the
 * development environment is ready.
 */
import { spawn } from 'child_process';

function startProcess(command: string, args: string[]): void {
  const proc = spawn(command, args, { stdio: 'inherit' });
  proc.on('close', (code) => {
    if (code !== 0) {
      console.error(`${command} ${args.join(' ')} exited with code ${code}`);
    }
  });
}

// Seed the D1 database with mock data. In a real environment you might load
// SQL files or call an ORM here. This function is a no-op in this sample.
function seedDatabase() {
  console.log('Seeding D1 database with mock data (stub)...');
}

function main() {
  console.log('Starting development environment...');
  seedDatabase();
  // Start the Cloudflare Worker using Wrangler. This watches your Worker
  // TypeScript file for changes and recompiles automatically.
  startProcess('npx', ['wrangler', 'dev', '--experimental-json-config']);
  // Start the Vite development server for the React frontend. This will
  // automatically proxy API requests to the Worker based on vite.config.ts.
  startProcess('npx', ['vite']);
}

main();