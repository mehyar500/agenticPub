import React, { useState } from 'react';

interface Message {
  from: 'user' | 'bot';
  text: string;
}

/**
 * Main application component. Provides a very simple chat interface that
 * demonstrates how to interact with the backend API implemented in the
 * Cloudflare Worker. Messages are stored locally in state and rendered
 * sequentially. When the user sends a message the app calls the `/llm/generate`
 * endpoint and displays the response from the server.
 */
const App: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [calling, setCalling] = useState(false);

  async function sendMessage() {
    if (!input) return;
    const msg = input;
    setMessages((prev) => [...prev, { from: 'user', text: msg }]);
    setInput('');
    try {
      const res = await fetch('/llm/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: msg })
      });
      const data = await res.json();
      setMessages((prev) => [...prev, { from: 'bot', text: data.response || data.answer || '...' }]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [...prev, { from: 'bot', text: 'Error contacting server.' }]);
    }
  }

  async function startCall() {
    setCalling(true);
    try {
      const res = await fetch('/calls/session');
      const data = await res.json();
      setMessages((prev) => [...prev, { from: 'bot', text: `Started a call session: ${data.sessionId}` }]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [...prev, { from: 'bot', text: 'Failed to start call session.' }]);
    } finally {
      setCalling(false);
    }
  }

  return (
    <div className="app-container">
      <h1>AI Receptionist</h1>
      <div className="controls">
        <button onClick={startCall} disabled={calling}>📞 {calling ? 'Calling...' : 'Start Call'}</button>
      </div>
      <div className="chat-window">
        {messages.map((m, idx) => (
          <div key={idx} className={`message ${m.from}`}>{m.text}</div>
        ))}
      </div>
      <div className="input-row">
        <input
          type="text"
          value={input}
          placeholder="Type a message"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              sendMessage();
            }
          }}
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};

export default App;