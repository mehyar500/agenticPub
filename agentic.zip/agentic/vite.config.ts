import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for the React frontend. This file tells Vite how to
// compile and bundle the application. We enable the React plugin here and
// configure a simple development server that proxies API requests to the
// Cloudflare Worker during local development.

export default defineConfig({
  plugins: [react()],
  server: {
    // Proxy API requests during development to the Wrangler dev server. When
    // running `npm run dev`, the `ops/devops.ts` script will start Wrangler
    // on port 8787 by default. Without this proxy the frontend would attempt
    // to fetch from its own origin and fail.
    proxy: {
      '/calls': 'http://localhost:8787',
      '/sip': 'http://localhost:8787',
      '/rag': 'http://localhost:8787',
      '/llm': 'http://localhost:8787',
      '/voice': 'http://localhost:8787'
    }
  },
  build: {
    outDir: 'dist/frontend',
    emptyOutDir: true,
    // Target the latest browsers supported by Cloudflare Pages.
    target: 'esnext'
  }
});